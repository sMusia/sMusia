

#ifndef wi_fi_h
#define wi_fi_h

#ifdef ESP8266
#include <ESP8266WiFi.h>
#else
#include <WiFi.h>
#endif


#endif